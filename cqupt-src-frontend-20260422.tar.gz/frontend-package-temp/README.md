# CQUPT-SRC 前端代码

这是 CQUPT-SRC 项目的前端代码打包，可独立用于与新后端集成。

## 快速开始

### 1. 安装依赖

```bash
npm install
```

### 2. 启动开发服务器

```bash
npm run dev
```

访问 http://localhost:5173 即可使用

### 3. 构建生产版本

```bash
npm run build
```

输出到 `dist/` 目录

## 文档

- **FRONTEND_PACKAGING_GUIDE.md** - 前端打包和交接指南
- **FRONTEND_CODE_CHECKLIST.md** - 前端代码清单和集成步骤
- **API_SPECIFICATION.md** - 完整的 API 接口规范 ⭐ 新后端必读
- **.env.example** - 环境变量模板

## 与新后端集成

1. 更新 `vite.config.ts` 中的 API 代理地址
2. 根据 API_SPECIFICATION.md 实现后端接口
3. 确保后端支持 CORS 和 HTTP Only Cookie
4. 测试所有认证和授权流程

## 技术栈

- React 19 + TypeScript 5
- Vite 6 (构建工具)
- Tailwind CSS 4 (样式)
- Lucide React (图标)
- Motion (动画)

详见 package.json

## 关键文件

- `src/types.ts` - 所有 TypeScript 类型定义 ⭐ 新后端参考
- `src/App.tsx` - 应用主入口，处理认证流程
- `src/views/Login.tsx` - 登录页面
- `src/views/Register.tsx` - 注册页面
- `src/components/SliderCaptcha.tsx` - 滑动验证码组件

## 需要新后端实现的功能

详见 API_SPECIFICATION.md，包括：

- 用户认证和授权
- 漏洞管理和审核
- 积分商城
- 学习中心
- 证书管理
- 等等...

维护时间：2026-04-22
